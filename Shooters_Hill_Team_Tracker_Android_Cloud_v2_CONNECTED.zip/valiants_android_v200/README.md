# Shooters Hill Team Tracker — Cloud v2.0.0

This version replaces APK-based role locks with server-enforced accounts. One APK is used by everyone. Supabase decides whether the signed-in user is a **Club Admin**, **Coach**, or **Parent**, and which team they can access.

## What changes

- **Club Admin** can see/switch between all club teams, create one-time Coach/Parent account invites, and edit any team.
- **Coach** is locked by the database to one team and can edit only that team.
- **Parent** is locked to one team and can only read it. Even a modified APK cannot write because Row Level Security blocks the request on the server.
- Team state is stored centrally in `team_state`, so a coach result update appears on parent devices after sync.
- The app checks for cloud changes every minute and whenever it returns to the foreground.
- Saves use revision checking so a stale device cannot silently overwrite a newer edit.
- Existing local Valiants data is uploaded automatically the first time an authorised editor opens a team that has no cloud state yet.
- Selkent sync, fixtures, league tables, squad, goals, awards, friendlies and existing tracker features remain in the same shared team state.

## 1. Create/configure Supabase

1. Create a Supabase project.
2. Open **SQL Editor** and run `supabase/schema.sql`.
3. Before running it, replace `CHANGE_ME_TO_CLUB_ADMIN_EMAIL@example.com` with the email you will use for the Club Admin account.
4. In Supabase **Project Settings → API**, copy the Project URL and anon/public key.
5. Put those two values into `app/src/main/assets/cloud-config.js`. The anon key is intended for client apps; security is enforced by RLS. Never put a service-role key in the app.

## 2. First admin account

Create an account in the app using exactly the bootstrap admin email from the SQL file. If email confirmation is enabled, confirm the email and then sign in. The database trigger promotes that account to `club_admin`.

## 3. Invite coaches and parents

In the app go to **More → Invite Coach or Parent**. Select a team and role and generate the one-time code. The recipient installs the same APK, creates/signs into their account, and claims the invite. From then on the team and role come from the server.

## 4. Build APK

The included GitHub Actions workflow builds one artifact: `Shooters-Hill-Team-Tracker.apk`.

## Security notes

- There is no private signing secret in the APK.
- Parent write attempts are rejected by RLS.
- Coaches can edit only their assigned team.
- Club Admin can access all teams in the club.
- Invite codes are stored only as SHA-256 hashes and are single-use.
- A lost/reinstalled phone simply signs back into the same account; the team assignment is recovered from the server.
