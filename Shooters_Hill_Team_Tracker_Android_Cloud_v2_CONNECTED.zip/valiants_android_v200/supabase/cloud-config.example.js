window.VALIANTS_CLOUD = {
  enabled: true,
  url: 'https://YOUR_PROJECT_REF.supabase.co',
  anonKey: 'YOUR_SUPABASE_ANON_KEY',
  syncIntervalMs: 60000
};
