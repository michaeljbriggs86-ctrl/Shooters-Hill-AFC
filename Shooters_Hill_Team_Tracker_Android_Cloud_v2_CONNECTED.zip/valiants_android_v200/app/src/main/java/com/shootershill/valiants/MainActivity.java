package com.shootershill.valiants;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.addJavascriptInterface(new NativeBridge(), "ValiantsNative");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html?build=cloud");
    }

    private class NativeBridge {
        @JavascriptInterface
        public void request(String requestId, String url, String method, String body) {
            new Thread(() -> {
                int status = 0;
                String response = "";
                String error = "";
                HttpURLConnection connection = null;
                try {
                    URL target = new URL(url);
                    connection = (HttpURLConnection) target.openConnection();
                    connection.setConnectTimeout(15000);
                    connection.setReadTimeout(20000);
                    connection.setInstanceFollowRedirects(true);
                    connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/126 Mobile Safari/537.36 ShootersHillTracker/2.0");
                    connection.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8");
                    String cookies = CookieManager.getInstance().getCookie(url);
                    if (cookies != null && !cookies.isEmpty()) connection.setRequestProperty("Cookie", cookies);
                    String httpMethod = (method == null || method.isEmpty()) ? "GET" : method.toUpperCase();
                    connection.setRequestMethod(httpMethod);
                    if (!"GET".equals(httpMethod) && body != null && !body.isEmpty()) {
                        byte[] payload = body.getBytes(StandardCharsets.UTF_8);
                        connection.setDoOutput(true);
                        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                        try (OutputStream os = connection.getOutputStream()) { os.write(payload); }
                    }
                    status = connection.getResponseCode();
                    java.util.List<String> setCookies = connection.getHeaderFields().get("Set-Cookie");
                    if (setCookies != null) for (String cookie : setCookies) CookieManager.getInstance().setCookie(url, cookie);
                    InputStream stream = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
                    if (stream != null) {
                        StringBuilder sb = new StringBuilder();
                        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                            String line; while ((line = reader.readLine()) != null) sb.append(line).append('\n');
                        }
                        response = sb.toString();
                    }
                } catch (Exception ex) {
                    error = ex.getMessage() == null ? ex.toString() : ex.getMessage();
                } finally { if (connection != null) connection.disconnect(); }

                final int finalStatus = status; final String finalResponse = response; final String finalError = error;
                webView.post(() -> webView.evaluateJavascript(
                    "window.__nativeFetchResolve(" + JSONObject.quote(requestId) + "," + finalStatus + "," + JSONObject.quote(finalResponse) + "," + JSONObject.quote(finalError) + ");", null));
            }).start();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
